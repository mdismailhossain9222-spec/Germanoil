import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter, Oswald } from "next/font/google";
import "./globals.css";

/** Body copy — clean neutral grotesque. */
const body = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

/** Display face — tall industrial condensed for headlines. */
const display = Oswald({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

export const metadata: Metadata = {
  title: "GermanOil Project — Premium Automotive & Industrial Lubricants",
  description:
    "Precision engineered in the UAE, powering Bangladesh. GermanOil Project manufactures and distributes premium automotive and industrial lubricants for cars, motorcycles and industry.",
  keywords: [
    "GermanOil",
    "lubricants",
    "engine oil",
    "hydraulic oil",
    "Dubai",
    "UAE",
    "Bangladesh",
  ],
};

export const viewport: Viewport = {
  themeColor: "#0A0A0A",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${body.variable} ${display.variable}`}>
      <body className="bg-ink font-sans text-white antialiased">
        {children}
      </body>
    </html>
  );
}
