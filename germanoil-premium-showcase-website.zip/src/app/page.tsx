import SiteHeader from "@/components/SiteHeader";
import Hero from "@/components/Hero";
import BrandStory from "@/components/BrandStory";
import ProductShowcase from "@/components/ProductShowcase";
import Quality from "@/components/Quality";
import Reach from "@/components/Reach";
import ContactSection from "@/components/ContactSection";
import SiteFooter from "@/components/SiteFooter";
import { getProducts } from "@/lib/products";

export const dynamic = "force-dynamic";

/** GermanOil Project — single-page premium showcase (no e-commerce). */
export default async function HomePage() {
  const products = await getProducts();

  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <BrandStory />
        <ProductShowcase products={products} />
        <Quality />
        <Reach />
        <ContactSection />
      </main>
      <SiteFooter />
    </>
  );
}
