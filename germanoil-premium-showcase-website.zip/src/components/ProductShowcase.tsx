import type { Product } from "@/db/schema";
import ProductCard from "./ProductCard";
import Reveal, { SectionHeading } from "./Reveal";

/** Responsive product grid: 1 column mobile → 3 columns desktop. */
export default function ProductShowcase({ products }: { products: Product[] }) {
  return (
    <section
      id="products"
      aria-labelledby="products-title"
      className="relative border-t border-graphite bg-ink py-24 sm:py-32"
    >
      <div
        aria-hidden="true"
        className="grid-texture pointer-events-none absolute inset-0 opacity-30"
      />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div
          id="products-title"
          className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between"
        >
          <SectionHeading
            eyebrow="The Lineup"
            title="Engineered for"
            accent="every engine."
            description="Three core formulations covering industrial hydraulics, motorcycles and modern petrol engines — each blended in the UAE and supplied across Bangladesh."
          />
          <Reveal delay={0.2}>
            <p className="max-w-xs rounded-sm border border-graphite bg-charcoal p-5 text-xs leading-relaxed tracking-wide text-muted">
              This catalogue is presented for information only. For pack sizes,
              availability and distribution, please contact our team.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-7 md:grid-cols-2 lg:grid-cols-3">
          {products.map((product, i) => (
            <ProductCard key={product.slug} product={product} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
