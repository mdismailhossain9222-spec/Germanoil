"use client";

import Image from "next/image";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ArrowDown, MapPin, ShieldCheck } from "lucide-react";

/** Staggered container for the premium text reveal. */
const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.11, delayChildren: 0.15 } },
};

/** Individual line / word reveal — soft fade + rise + blur. */
const rise = {
  hidden: { opacity: 0, y: 36, filter: "blur(10px)" },
  show: {
    opacity: 1,
    y: 0,
    filter: "blur(0px)",
    transition: { duration: 0.85, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const HEADLINE_A = ["Precision", "Engineered", "in", "UAE."];
const HEADLINE_B = ["Powering", "Bangladesh."];

export default function Hero() {
  const ref = useRef<HTMLElement>(null);

  // Parallax: background texture drifts slower than the page scroll.
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const textureY = useTransform(scrollYProgress, [0, 1], ["0%", "28%"]);
  const contentY = useTransform(scrollYProgress, [0, 1], ["0%", "-12%"]);
  const fade = useTransform(scrollYProgress, [0, 0.85], [1, 0]);

  return (
    <section
      id="top"
      ref={ref}
      aria-label="Introduction"
      className="relative flex min-h-screen items-center overflow-hidden bg-ink"
    >
      {/* Layer 1 — abstract oil-flow texture, heavily darkened */}
      <motion.div
        style={{ y: textureY }}
        className="pointer-events-none absolute inset-0 -top-[10%] h-[120%]"
        aria-hidden="true"
      >
        <Image
          src="/images/hero-texture.jpg"
          alt=""
          fill
          priority
          sizes="100vw"
          className="object-cover opacity-[0.28] mix-blend-screen"
        />
      </motion.div>

      {/* Layer 2 — gradient scrims keeping everything luxuriously dark */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_90%_at_72%_18%,rgba(201,168,92,0.20),transparent_58%),radial-gradient(90%_70%_at_8%_90%,rgba(181,19,15,0.14),transparent_60%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-gradient-to-b from-ink via-ink/55 to-ink"
      />
      <div
        aria-hidden="true"
        className="grid-texture pointer-events-none absolute inset-0 opacity-40"
      />

      {/* Layer 3 — content */}
      <motion.div
        style={{ y: contentY, opacity: fade }}
        className="relative z-10 mx-auto w-full max-w-7xl px-5 pt-32 pb-24 sm:px-8"
      >
        <motion.div variants={container} initial="hidden" animate="show">
          {/* Eyebrow */}
          <motion.div
            variants={rise}
            className="mb-8 inline-flex items-center gap-3 rounded-full border border-graphite bg-charcoal/70 px-4 py-2 backdrop-blur"
          >
            <MapPin className="h-3.5 w-3.5 text-gold" aria-hidden="true" />
            <span className="text-[10px] font-semibold tracking-[0.28em] text-muted uppercase sm:text-[11px]">
              Manufactured in Dubai, UAE · Distributed across Bangladesh
            </span>
          </motion.div>

          {/* Headline — word by word stagger */}
          <h1 className="font-display max-w-5xl text-[2.6rem] leading-[0.98] font-bold tracking-tight uppercase sm:text-6xl lg:text-[5.4rem]">
            <span className="block">
              {HEADLINE_A.map((w) => (
                <motion.span
                  key={w}
                  variants={rise}
                  className="mr-[0.28em] inline-block text-white"
                >
                  {w}
                </motion.span>
              ))}
            </span>
            <span className="mt-1 block">
              {HEADLINE_B.map((w) => (
                <motion.span
                  key={w}
                  variants={rise}
                  className="text-gold-gradient mr-[0.28em] inline-block"
                >
                  {w}
                </motion.span>
              ))}
            </span>
          </h1>

          {/* Gold hairline */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 1.1, delay: 0.9, ease: "easeOut" }}
            className="hairline my-8 w-full max-w-md origin-left"
            aria-hidden="true"
          />

          <motion.p
            variants={rise}
            className="max-w-xl text-base leading-relaxed text-muted sm:text-lg"
          >
            Premium Automotive &amp; Industrial Lubricants — blended to German
            specification, tested for tropical conditions, trusted by workshops
            and plants nationwide.
          </motion.p>

          {/* Actions — informational only, no commerce */}
          <motion.div
            variants={rise}
            className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center"
          >
            <a
              href="#products"
              className="group inline-flex items-center justify-center gap-3 rounded-sm bg-german-red px-8 py-4 text-[11px] font-bold tracking-[0.22em] text-white uppercase transition-colors duration-300 hover:bg-signal-red"
            >
              Explore the Lineup
              <ArrowDown className="h-4 w-4 transition-transform duration-300 group-hover:translate-y-1" aria-hidden="true" />
            </a>
            <a
              href="#story"
              className="inline-flex items-center justify-center gap-3 rounded-sm border border-graphite px-8 py-4 text-[11px] font-bold tracking-[0.22em] text-white uppercase transition-all duration-300 hover:border-gold hover:text-gold-light"
            >
              Our Story
            </a>
          </motion.div>

          {/* Trust strip */}
          <motion.ul
            variants={rise}
            className="mt-14 flex flex-wrap items-center gap-x-10 gap-y-4"
          >
            {[
              "API & ISO aligned blending",
              "Tropical-climate tested",
              "Nationwide BD distribution",
            ].map((item) => (
              <li key={item} className="flex items-center gap-2.5">
                <ShieldCheck className="h-4 w-4 text-gold-dark" aria-hidden="true" />
                <span className="text-[11px] tracking-[0.14em] text-muted uppercase">
                  {item}
                </span>
              </li>
            ))}
          </motion.ul>
        </motion.div>
      </motion.div>

      {/* Scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.8 }}
        className="absolute inset-x-0 bottom-6 z-10 flex justify-center"
        aria-hidden="true"
      >
        <motion.span
          animate={{ y: [0, 9, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="text-[10px] tracking-[0.35em] text-muted/70 uppercase"
        >
          Scroll
        </motion.span>
      </motion.div>
    </section>
  );
}
