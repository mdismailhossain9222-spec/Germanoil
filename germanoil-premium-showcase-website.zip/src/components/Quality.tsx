"use client";

import { motion } from "framer-motion";
import { Beaker, ClipboardCheck, Recycle, ThermometerSun } from "lucide-react";
import Reveal, { SectionHeading } from "./Reveal";

const STANDARDS = [
  {
    icon: Beaker,
    title: "Laboratory Verified",
    copy: "Viscosity index, flash point and TBN checked on every production batch before release.",
  },
  {
    icon: ClipboardCheck,
    title: "Specification Led",
    copy: "Formulated to meet and exceed API, ISO and OEM performance requirements for each grade.",
  },
  {
    icon: ThermometerSun,
    title: "Thermal Stability",
    copy: "Oxidation-resistant chemistry that holds film strength through sustained high temperatures.",
  },
  {
    icon: Recycle,
    title: "Responsible Packaging",
    copy: "Tamper-evident, recyclable containers with batch traceability printed on every unit.",
  },
];

const STATS = [
  { value: "2015", label: "Founded in Dubai" },
  { value: "64", label: "Districts reached in BD" },
  { value: "100%", label: "Batch tested" },
  { value: "3", label: "Core formulations" },
];

/** Light off-white contrast band — used sparingly for visual rhythm. */
export default function Quality() {
  return (
    <section
      id="quality"
      aria-labelledby="quality-title"
      className="relative bg-offwhite py-24 text-ink sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div id="quality-title">
          <SectionHeading
            light
            align="center"
            eyebrow="Quality Commitment"
            title="No shortcuts."
            accent="Ever."
            description="Lubricant quality is invisible until it fails. That is exactly why we over-engineer it — with disciplined blending, documented testing and traceable packaging."
          />
        </div>

        <ul className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {STANDARDS.map((s, i) => (
            <li key={s.title}>
              <Reveal delay={i * 0.08}>
                <div className="h-full border-t-2 border-ink/10 pt-6 transition-colors duration-500 hover:border-gold-dark">
                  <s.icon className="h-6 w-6 text-gold-dark" aria-hidden="true" />
                  <h3 className="font-display mt-4 text-lg tracking-wide uppercase">
                    {s.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-ink/65">
                    {s.copy}
                  </p>
                </div>
              </Reveal>
            </li>
          ))}
        </ul>

        {/* Stats band */}
        <motion.dl
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
          className="mt-20 grid grid-cols-2 gap-px overflow-hidden rounded-sm bg-ink/10 lg:grid-cols-4"
        >
          {STATS.map((s) => (
            <div key={s.label} className="bg-offwhite px-6 py-8 text-center">
              <dt className="sr-only">{s.label}</dt>
              <dd>
                <span className="font-display block text-4xl font-bold text-ink sm:text-5xl">
                  {s.value}
                </span>
                <span className="mt-2 block text-[10px] tracking-[0.22em] text-ink/55 uppercase">
                  {s.label}
                </span>
              </dd>
            </div>
          ))}
        </motion.dl>
      </div>
    </section>
  );
}
