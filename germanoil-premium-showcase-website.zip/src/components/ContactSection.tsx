"use client";

import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Mail, MapPin, Phone, Send, CheckCircle2, AlertCircle } from "lucide-react";
import Reveal, { SectionHeading } from "./Reveal";

type Status = "idle" | "sending" | "sent" | "error";

const OFFICES = [
  {
    region: "United Arab Emirates",
    city: "Dubai — Manufacturing & Export",
    lines: ["Industrial Area, Jebel Ali", "Dubai, UAE"],
    phone: "+971 4 000 0000",
  },
  {
    region: "Bangladesh",
    city: "Dhaka — Distribution Office",
    lines: ["Tejgaon Industrial Area", "Dhaka 1208, Bangladesh"],
    phone: "+880 1700 000000",
  },
];

/**
 * Distribution / information enquiry form.
 * This is NOT an order form — no products, quantities or payments.
 */
export default function ContactSection() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());

    setStatus("sending");
    setError("");

    try {
      const res = await fetch("/api/enquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Something went wrong.");
      setStatus("sent");
      form.reset();
    } catch (err) {
      setStatus("error");
      setError(err instanceof Error ? err.message : "Something went wrong.");
    }
  }

  const field =
    "w-full rounded-sm border border-graphite bg-ink px-4 py-3 text-sm text-white placeholder:text-muted/60 transition-colors duration-300 focus:border-gold focus:outline-none";

  return (
    <section
      id="contact"
      aria-labelledby="contact-title"
      className="relative border-t border-graphite bg-ink py-24 sm:py-32"
    >
      <div className="mx-auto grid max-w-7xl gap-16 px-5 sm:px-8 lg:grid-cols-2 lg:gap-20">
        <div>
          <div id="contact-title">
            <SectionHeading
              eyebrow="Get in Touch"
              title="Partner with"
              accent="GermanOil."
              description="Distributors, workshops and industrial buyers are welcome to request product data sheets, pack availability and partnership information."
            />
          </div>

          <ul className="mt-12 space-y-8">
            {OFFICES.map((o, i) => (
              <li key={o.region}>
                <Reveal delay={i * 0.1}>
                  <div className="rounded-sm border border-graphite bg-charcoal p-6">
                    <span className="text-[10px] font-semibold tracking-[0.26em] text-gold uppercase">
                      {o.region}
                    </span>
                    <h3 className="font-display mt-3 text-lg tracking-wide text-white uppercase">
                      {o.city}
                    </h3>
                    <p className="mt-3 flex items-start gap-3 text-sm text-muted">
                      <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-dark" aria-hidden="true" />
                      <span>{o.lines.join(", ")}</span>
                    </p>
                    <p className="mt-2 flex items-center gap-3 text-sm text-muted">
                      <Phone className="h-4 w-4 shrink-0 text-gold-dark" aria-hidden="true" />
                      <span>{o.phone}</span>
                    </p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>

          <Reveal delay={0.2}>
            <a
              href="mailto:info@germanoilproject.com"
              className="mt-8 inline-flex items-center gap-3 text-sm tracking-[0.14em] text-gold uppercase transition-colors hover:text-gold-light"
            >
              <Mail className="h-4 w-4" aria-hidden="true" />
              info@germanoilproject.com
            </a>
          </Reveal>
        </div>

        {/* Enquiry form */}
        <Reveal delay={0.12}>
          <form
            onSubmit={onSubmit}
            className="rounded-sm border border-graphite bg-charcoal p-7 sm:p-9"
            aria-label="Information enquiry form"
          >
            <h3 className="font-display text-xl tracking-wide text-white uppercase">
              Request Information
            </h3>
            <p className="mt-2 text-xs tracking-wide text-muted">
              No orders are processed through this website.
            </p>

            <div className="mt-7 space-y-5">
              <div>
                <label htmlFor="name" className="mb-2 block text-[10px] tracking-[0.2em] text-muted uppercase">
                  Full Name *
                </label>
                <input id="name" name="name" required minLength={2} className={field} placeholder="Your name" />
              </div>
              <div>
                <label htmlFor="email" className="mb-2 block text-[10px] tracking-[0.2em] text-muted uppercase">
                  Email Address *
                </label>
                <input id="email" name="email" type="email" required className={field} placeholder="you@company.com" />
              </div>
              <div>
                <label htmlFor="company" className="mb-2 block text-[10px] tracking-[0.2em] text-muted uppercase">
                  Company
                </label>
                <input id="company" name="company" className={field} placeholder="Company / workshop name" />
              </div>
              <div>
                <label htmlFor="message" className="mb-2 block text-[10px] tracking-[0.2em] text-muted uppercase">
                  Message *
                </label>
                <textarea id="message" name="message" required minLength={5} rows={4} className={`${field} resize-none`} placeholder="Tell us what information you need…" />
              </div>
            </div>

            <motion.button
              type="submit"
              disabled={status === "sending"}
              whileTap={{ scale: 0.98 }}
              className="mt-7 inline-flex w-full items-center justify-center gap-3 rounded-sm bg-german-red px-8 py-4 text-[11px] font-bold tracking-[0.22em] text-white uppercase transition-colors duration-300 hover:bg-signal-red disabled:cursor-not-allowed disabled:opacity-60"
            >
              {status === "sending" ? "Sending…" : "Send Enquiry"}
              <Send className="h-4 w-4" aria-hidden="true" />
            </motion.button>

            <div aria-live="polite" className="mt-4 min-h-[1.5rem]">
              {status === "sent" && (
                <p className="flex items-center gap-2 text-sm text-gold-light">
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  Thank you — our team will be in touch shortly.
                </p>
              )}
              {status === "error" && (
                <p className="flex items-center gap-2 text-sm text-signal-red">
                  <AlertCircle className="h-4 w-4" aria-hidden="true" />
                  {error}
                </p>
              )}
            </div>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
